# SIG Platform - Deploy to VPSBG (87.121.52.49)

## First Deploy

```bash
# On your local machine
scp -r sig-platform/ root@87.121.52.49:/home/

# On the server
ssh root@87.121.52.49
cd /home/sig-platform
cp .env.example .env
nano .env          # fill in DATABASE_URL at minimum

docker-compose up -d
docker-compose logs -f sig-ingest    # watch for errors

# Test
python tests/test_synthetic.py
```

## Ports
- 5010  sig-ingest API (this project)
- 5000-5007  Total Reality Ecosystem (existing, no conflict)

## Update After Changes
```bash
docker-compose down
git pull
docker-compose up -d --build
```
